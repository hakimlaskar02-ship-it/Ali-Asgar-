# আলী আজগর সিদ্দিকিয়া মাদ্রাসা — Supabase Ready Native Android

এই ZIP-এ Supabase database/auth-এর বাস্তব starter code যোগ করা হয়েছে।

## 1. Supabase-এ database বানাও
Supabase Dashboard → SQL Editor → `supabase/schema.sql`-এর পুরো code paste করে Run করো।

## 2. Admin account বানাও
Supabase Dashboard → Authentication → Users → Add user থেকে admin email/password তৈরি করো।
তারপর SQL Editor-এ চালাও:

```sql
insert into public.admin_users(user_id)
select id from auth.users where email = 'তোমার-admin-email@example.com';
```

## 3. Android app-এ Supabase key বসাও
`app/src/main/java/com/ali/azgar/madrasa/SupabaseConfig.kt` খুলে:
- `URL` = Supabase Project URL
- `PUBLISHABLE_KEY` = Supabase Publishable/anon key

**service_role/secret key কখনো Android app-এ দেবে না।**

## 4. কী কাজ করছে
- Supabase Auth admin login
- Members read/add
- Monthly dues read/mark paid
- Expenses read/add
- Notices read/publish
- App settings (monthly due, payment text, QR URL) database-ready
- RLS: সাধারণ user read করতে পারে, শুধু `admin_users`-এর authenticated user edit করতে পারে
- Realtime tables enabled

## 5. QR image
QR-এর জন্য Supabase Storage bucket ব্যবহার করে পরে upload UI যোগ করা যাবে। Database-এ `qr_url` setting রাখা আছে।

## Important
এই project-এ placeholder Supabase URL/key আছে। তোমার নিজের project credentials না বসালে app database-এ connect করবে না।
