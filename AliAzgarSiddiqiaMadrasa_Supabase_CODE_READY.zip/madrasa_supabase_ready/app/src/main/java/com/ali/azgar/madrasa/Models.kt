package com.ali.azgar.madrasa

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Member(
    val id: String,
    @SerialName("member_id") val memberId: Long,
    val name: String,
    val phone: String? = null,
    @SerialName("photo_url") val photoUrl: String? = null,
    @SerialName("join_date") val joinDate: String? = null
)

@Serializable
data class Due(
    val id: String,
    @SerialName("member_id") val memberId: String,
    val month: String,
    val amount: Double,
    @SerialName("paid_at") val paidAt: String? = null,
    val status: String = "unpaid"
)

@Serializable
data class Expense(
    val id: String,
    val title: String,
    val amount: Double,
    @SerialName("expense_date") val expenseDate: String? = null,
    val note: String? = null
)

@Serializable
data class Notice(
    val id: String,
    val title: String,
    val body: String,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class AppSetting(
    val key: String,
    val value: String
)

@Serializable
data class NewMember(
    val name: String,
    val phone: String? = null,
    @SerialName("photo_url") val photoUrl: String? = null
)

@Serializable
data class NewExpense(
    val title: String,
    val amount: Double,
    val note: String? = null
)

@Serializable
data class NewNotice(
    val title: String,
    val body: String
)

@Serializable
data class NewDue(
    @SerialName("member_id") val memberId: String,
    val month: String,
    val amount: Double,
    val status: String = "paid",
    @SerialName("paid_at") val paidAt: String
)
