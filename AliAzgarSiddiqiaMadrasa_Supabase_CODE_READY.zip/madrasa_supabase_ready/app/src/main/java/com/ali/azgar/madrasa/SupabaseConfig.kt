package com.ali.azgar.madrasa

object SupabaseConfig {
    // Replace these two values with the Project URL and Publishable (anon) key
    // from Supabase Dashboard > Connect. NEVER put a service_role/secret key here.
    const val URL = "https://YOUR_PROJECT_REF.supabase.co"
    const val PUBLISHABLE_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY"
}
