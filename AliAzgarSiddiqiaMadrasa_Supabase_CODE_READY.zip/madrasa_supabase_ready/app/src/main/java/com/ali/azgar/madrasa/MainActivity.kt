package com.ali.azgar.madrasa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MadrasaApp() }
    }
}

@Composable
fun MadrasaApp() {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var members by remember { mutableStateOf<List<Member>>(emptyList()) }
    var dues by remember { mutableStateOf<List<Due>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var notices by remember { mutableStateOf<List<Notice>>(emptyList()) }
    var loggedIn by remember { mutableStateOf(supabase.auth.currentUserOrNull() != null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() = scope.launch {
        try {
            members = MadrasaRepository.members()
            dues = MadrasaRepository.dues()
            expenses = MadrasaRepository.expenses()
            notices = MadrasaRepository.notices()
        } catch (e: Exception) { message = e.message ?: "ডাটা লোড হয়নি" }
    }
    LaunchedEffect(Unit) { refresh() }

    MaterialTheme {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("আলী আজগর সিদ্দিকিয়া মাদ্রাসা") },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color(0xFF064E3B), titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("হোম", "সদস্য", "চাঁদা", "খরচ", "নোটিশ").forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, label = { Text(label) }, icon = {})
                    }
                }
            }
        ) { p ->
            Column(Modifier.fillMaxSize().padding(p).padding(16.dp)) {
                if (message != null) Text(message!!, color = MaterialTheme.colorScheme.error)
                when (tab) {
                    0 -> Home(members, dues, expenses, notices, loggedIn, onAdmin = { tab = 5 })
                    1 -> MembersScreen(members, loggedIn, scope, onRefresh = { refresh() }, onMessage = { message = it })
                    2 -> DuesScreen(members, dues, loggedIn, scope, onRefresh = { refresh() }, onMessage = { message = it })
                    3 -> ExpensesScreen(expenses, loggedIn, scope, onRefresh = { refresh() }, onMessage = { message = it })
                    4 -> NoticesScreen(notices, loggedIn, scope, onRefresh = { refresh() }, onMessage = { message = it })
                    5 -> AdminScreen(loggedIn, scope, onLogged = { loggedIn = it; refresh() }, onMessage = { message = it })
                }
            }
        }
    }
}

@Composable private fun Home(m: List<Member>, d: List<Due>, e: List<Expense>, n: List<Notice>, admin: Boolean, onAdmin: () -> Unit) {
    val income = d.filter { it.status == "paid" }.sumOf { it.amount }
    val cost = e.sumOf { it.amount }
    Text("মাদ্রাসা ব্যবস্থাপনা", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Text("মোট সদস্য: ${m.size} জন")
    Text("চাঁদা উঠেছে: ${income.toInt()} টাকা")
    Text("মোট খরচ: ${cost.toInt()} টাকা")
    Text("বর্তমান ব্যালেন্স: ${(income - cost).toInt()} টাকা")
    Spacer(Modifier.height(16.dp))
    Text("📢 ${n.firstOrNull()?.title ?: "কোনো নোটিশ নেই"}")
    if (!admin) { Spacer(Modifier.height(20.dp)); Button(onClick = onAdmin) { Text("🔐 Admin Login") } }
}

@Composable private fun MembersScreen(members: List<Member>, admin: Boolean, scope: kotlinx.coroutines.CoroutineScope, onRefresh: () -> Unit, onMessage: (String) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    Text("👥 সদস্য তালিকা", style = MaterialTheme.typography.headlineSmall)
    if (admin) {
        OutlinedTextField(name, { name = it }, label = { Text("নাম") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("ফোন (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { try { MadrasaRepository.addMember(name, phone.ifBlank { null }); name=""; phone=""; onRefresh() } catch(e:Exception){onMessage(e.message ?: "Error")} } }) { Text("+ সদস্য যোগ করুন") }
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(members) { Text("${it.memberId}. ${it.name}${it.phone?.let { p -> " • $p" } ?: ""}") } }
}

@Composable private fun DuesScreen(members: List<Member>, dues: List<Due>, admin: Boolean, scope: kotlinx.coroutines.CoroutineScope, onRefresh: () -> Unit, onMessage: (String) -> Unit) {
    Text("💰 মাসিক চাঁদা", style = MaterialTheme.typography.headlineSmall)
    Text("নিয়ম: প্রতি মাসের ১–১০ তারিখের মধ্যে চাঁদা জমা")
    if (admin) members.take(20).forEach { member ->
        val paid = dues.any { it.memberId == member.id && it.status == "paid" }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${member.memberId}. ${member.name}")
            Button(enabled = !paid, onClick = { scope.launch { try { MadrasaRepository.markPaid(member.id, "${java.time.LocalDate.now().withDayOfMonth(1)}", MadrasaRepository.setting("monthly_due")?.toDoubleOrNull() ?: 100.0); onRefresh() } catch(e:Exception){onMessage(e.message ?: "Error")} } }) { Text(if (paid) "দেওয়া" else "Paid") }
        }
    }
}

@Composable private fun ExpensesScreen(expenses: List<Expense>, admin: Boolean, scope: kotlinx.coroutines.CoroutineScope, onRefresh: () -> Unit, onMessage: (String) -> Unit) {
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    Text("🧾 খরচের হিসাব", style = MaterialTheme.typography.headlineSmall)
    if (admin) {
        OutlinedTextField(title, { title = it }, label = { Text("খরচের নাম") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(amount, { amount = it }, label = { Text("টাকা") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { try { MadrasaRepository.addExpense(title, amount.toDouble()); title=""; amount=""; onRefresh() } catch(e:Exception){onMessage(e.message ?: "Error")} } }) { Text("+ খরচ যোগ করুন") }
    }
    LazyColumn { items(expenses) { Text("${it.title} — ${it.amount.toInt()} টাকা") } }
}

@Composable private fun NoticesScreen(notices: List<Notice>, admin: Boolean, scope: kotlinx.coroutines.CoroutineScope, onRefresh: () -> Unit, onMessage: (String) -> Unit) {
    var title by remember { mutableStateOf("") }; var body by remember { mutableStateOf("") }
    Text("📢 নোটিশ বোর্ড", style = MaterialTheme.typography.headlineSmall)
    if (admin) {
        OutlinedTextField(title, { title = it }, label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(body, { body = it }, label = { Text("বিস্তারিত") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { try { MadrasaRepository.addNotice(title, body); title=""; body=""; onRefresh() } catch(e:Exception){onMessage(e.message ?: "Error")} } }) { Text("Publish") }
    }
    LazyColumn { items(notices) { Text("${it.title}\n${it.body}\n") } }
}

@Composable private fun AdminScreen(loggedIn: Boolean, scope: kotlinx.coroutines.CoroutineScope, onLogged: (Boolean) -> Unit, onMessage: (String) -> Unit) {
    if (loggedIn) {
        Text("🔐 Admin Mode", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { scope.launch { MadrasaRepository.logout(); onLogged(false) } }) { Text("Logout") }
    } else {
        var email by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
        Text("Admin Login", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { try { MadrasaRepository.login(email, pass); onLogged(true) } catch(e:Exception){onMessage(e.message ?: "Login failed")} } }) { Text("Login") }
    }
}
