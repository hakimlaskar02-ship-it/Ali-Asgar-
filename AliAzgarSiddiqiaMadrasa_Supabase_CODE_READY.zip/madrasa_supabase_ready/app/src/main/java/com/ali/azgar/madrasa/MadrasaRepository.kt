package com.ali.azgar.madrasa

import io.github.jan.supabase.auth.providers.Email
import io.github.jan.supabase.postgrest.from
import kotlinx.serialization.json.JsonObject

object MadrasaRepository {
    suspend fun login(email: String, password: String) {
        supabase.auth.signInWith(Email) {
            this.email = email
            this.password = password
        }
        if (supabase.auth.currentUserOrNull() == null) error("Login failed")
        val uid = supabase.auth.currentUserOrNull()!!.id
        supabase.from("admin_users").select { filter { eq("user_id", uid) } }
            .decodeList<JsonObject>()
            .takeIf { it.isNotEmpty() } ?: run { supabase.auth.signOut(); error("এই account Admin নয়") }
    }

    suspend fun logout() = supabase.auth.signOut()

    suspend fun members(): List<Member> = supabase.from("members").select().decodeList()

    suspend fun addMember(name: String, phone: String?, photoUrl: String? = null) {
        supabase.from("members").insert(NewMember(name, phone, photoUrl))
    }

    suspend fun dues(): List<Due> = supabase.from("dues").select().decodeList()

    suspend fun markPaid(memberId: String, month: String, amount: Double) {
        supabase.from("dues").upsert(
            NewDue(memberId, month, amount, "paid", java.time.Instant.now().toString())
        ) { onConflict = "member_id,month" }
    }

    suspend fun expenses(): List<Expense> = supabase.from("expenses").select().decodeList()

    suspend fun addExpense(title: String, amount: Double, note: String?) {
        supabase.from("expenses").insert(NewExpense(title, amount, note))
    }

    suspend fun notices(): List<Notice> = supabase.from("notices").select().decodeList()

    suspend fun addNotice(title: String, body: String) {
        supabase.from("notices").insert(NewNotice(title, body))
    }

    suspend fun setting(key: String): String? = supabase.from("app_settings").select {
        filter { eq("key", key) }
    }.decodeList<AppSetting>().firstOrNull()?.value

    suspend fun saveSetting(key: String, value: String) {
        supabase.from("app_settings").upsert(AppSetting(key, value)) { onConflict = "key" }
    }
}
